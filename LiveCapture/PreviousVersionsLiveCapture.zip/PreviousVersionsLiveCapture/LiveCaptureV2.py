# -*- coding: utf-8 -*-
"""
Created on Sat Apr  1 17:04:10 2023

@author: Callum Manning

Strath Uni - 201720173

"""

from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys
import binascii
from scapy.all import sniff

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        # Set window properties
        self.setWindowTitle("Packet Capture")
        self.setGeometry(100, 100, 800, 600)

        # Create text widgets for buffer and packet data
        self.buffer_text = QTextEdit(self)
        self.buffer_text.setGeometry(20, 20, 360, 280)
        self.packet_text = QTextEdit(self)
        self.packet_text.setGeometry(400, 20, 360, 280)

        # Create a button to start packet capture
        self.capture_button = QPushButton("Start Capture", self)
        self.capture_button.setGeometry(20, 320, 120, 40)
        self.capture_button.clicked.connect(self.start_capture)

        # Create a button to stop packet capture
        self.stop_button = QPushButton("Stop Capture", self)
        self.stop_button.setGeometry(150, 320, 120, 40)
        self.stop_button.clicked.connect(self.stop_capture)

        # Initialize packet capture variables
        self.packet_count = 0
        self.sniff_thread = None

    def start_capture(self):
        # Start packet capture thread
        self.sniff_thread = SniffThread(self)
        self.sniff_thread.start()

    def stop_capture(self):
        # Stop packet capture thread
        self.sniff_thread.stop()

    def packet_handler(self, pkt):
        # Increment packet count
        self.packet_count += 1

        # Extract packet data and display in hexadecimal format
        packet_data = binascii.hexlify(bytes(pkt)).decode()
        self.packet_text.append(f"Packet {self.packet_count}:\n{packet_data}\n")

        # Update buffer data and display in hexadecimal format
        buffer_data = self.get_buffer_data()
        self.buffer_text.setText(buffer_data)

    def get_buffer_data(self):
        # Get buffer data and format as hexadecimal string
        buffer_data = len(self.sniff_thread.packet_list)
        buffer_data = binascii.hexlify(buffer_data.to_bytes(4, 'big')).decode()

        return buffer_data

class SniffThread(QThread):
    packet_list_updated = pyqtSignal()

    def __init__(self, main_window):
        super().__init__()

        # Store reference to main window
        self.main_window = main_window

        # Initialize packet list
        self.packet_list = []

        # Set up packet sniffer
        self.sniffer = None

    def run(self):
        # Start packet capture loop
        self.sniffer = sniff(prn=self.packet_handler, store=False)
        self.sniffer.run()

    def stop(self):
        # Stop packet capture loop
        if self.sniffer is not None:
            self.sniffer.sniff_stop()

    def packet_handler(self, pkt):
        # Add packet to list
        self.packet_list.append(pkt)

        # Emit signal to update main window
        self.packet_list_updated.emit()


if __name__ == '__main__':
    # Create the application and main window
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()

    # Run the application loop
    sys.exit(app.exec_())

