# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 19:00:33 2023

@author: callu
"""

import numpy as np
from PIL import Image
from scapy.all import sniff
import platform
import PySimpleGUI as sg
import io

def extendbyte(start, end,bi):
     return int((int(bi[start:end],2)/8) * 2**8)

def gray2rgb(byte):
     bi = format(byte,'08b').replace("0b", "")
     r = extendbyte(0,3,bi)
     g = extendbyte(2,5,bi)
     b = extendbyte(7,8,bi)
     return([r,g,b])

def create_and_update_image(buffer, index):
    if platform.system() == 'Windows':
        # grayscale image
        num_pixels = np.random.randint(50, 151)
        for i in range(num_pixels):
            new_value = np.random.randint(0, 256)
            buffer[index] = new_value
            index += 1
            if index == buffer.shape[0]:
                buffer[:-1] = buffer[1:]
                buffer[-1] = new_value
                index = buffer.shape[0] - 1
        gray_image = Image.fromarray(buffer.reshape((150, 150)), mode="L")

        # rgb image
        rgb_buffer = np.zeros((buffer_size*3,), dtype=np.uint8)
        for i in range(buffer_size):
            rgb = gray2rgb(buffer[i])
            rgb_buffer[i*3:(i+1)*3] = rgb
        rgb_image = Image.fromarray(rgb_buffer.reshape((150, 150, 3)), mode="RGB")
    else:
        packets = sniff(count=100, iface="lo")
        new_values = []
        for packet in packets:
            if packet.haslayer('Raw'):
                data = packet.getlayer('Raw').load
                for byte in data:
                    byte = byte + 1
                    if byte > 255: 
                        byte = 255
                    new_values += [byte]
        for new_value in new_values:
            buffer[index] = new_value
            index += 1
            if index == buffer.shape[0]:
                buffer[:-1] = buffer[1:]
                buffer[-1] = new_value
                index = buffer.shape[0] - 1
        gray_image = Image.fromarray(buffer.reshape((150, 150)), mode="L")
        # rgb image
        rgb_buffer = np.zeros((buffer_size*3,), dtype=np.uint8)
        for i in range(buffer_size):
            rgb = gray2rgb(buffer[i])
            rgb_buffer[i*3:(i+1)*3] = rgb
        rgb_image = Image.fromarray(rgb_buffer.reshape((150, 150, 3)), mode="RGB")
    return gray_image, rgb_image, buffer, index


def show_Image(Im, key):
    image =Im
    # Resize the image to a larger size
    image = image.resize((300, 300))
    bio = io.BytesIO()
    image.save(bio, format="PNG")
    window[key].update(data=bio.getvalue()) # Updating the GUI window using the key that passed in


# Define the PySimpleGUI layout
layout = [
    [sg.Image(key='-GRAY-'), sg.Image(key='-RGB-')],
    [sg.Button('Pause/Start', key='-PAUSE-'), sg.Button('Clear Capture', key='-CLEAR-'), sg.Button('Exit', key='-EXIT-')]
]

# Create the PySimpleGUI window
window = sg.Window('Image Viewer', layout)
buffer_size = 22500
buffer_index = 0
buffer = np.zeros((buffer_size,), dtype=np.uint8)
is_paused = False
# Event loop
while True:
    event, values = window.read(timeout=10) # Add timeout to the read function to prevent blocking the loop
    if event == sg.WIN_CLOSED or event == '-EXIT-':
        break
    if event == '-PAUSE-':
        is_paused = not is_paused
    if event == '-CLEAR-':
        buffer_index = 0
        buffer = np.zeros((buffer_size,), dtype=np.uint8)
    if not is_paused:
        # Call the create_and_update_image() function to get the updated image and the new buffer state
        gray_image, rgb_image, buffer, buffer_index = create_and_update_image(buffer, buffer_index)

        # Update the images in the PySimpleGUI window
        show_Image(gray_image, '-GRAY-')
        show_Image(rgb_image, '-RGB-')
        window.refresh()
        
# Close the window
window.close()

