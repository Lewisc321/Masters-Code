import PySimpleGUI as sg
import io
from PIL import Image
import numpy as np
import numpy as np
from PIL import Image
import platform
import subprocess
import string
import re


def old_create_and_update_image(buffer, index):
    # Choose a random value between 0 and 255
    new_value = np.random.randint(0, 256)
    # Update the buffer with the new value
    buffer[index] = new_value
    # Increment the buffer index
    index += 1
    # Check if the buffer index has reached the end
    if index == buffer.shape[0]:
        # Shift the buffer back by one element and add the new value at the end
        buffer[:-1] = buffer[1:]
        buffer[-1] = new_value
        # Reset the buffer index
        index = buffer.shape[0] - 1
    # Reshape the buffer into a 150x150 image
    image = Image.fromarray(buffer.reshape((150, 150)), mode="L")
    return image, buffer, index

# read output line by line and extract packet data
def extract_packet_data(line):
    hex_data = re.findall(r'[0-9a-fA-F]{2} ', line)
    hex_data = [int(h, 16) for h in hex_data]
    # process the packet data here
    return hex_data

def create_and_update_image(buffer, index):
 # Check the platform
    if platform.system() == 'Windows':
        # Choose a random value between 0 and 255
        num_pixels = np.random.randint(50, 151)
        for i in range(num_pixels):
            # Choose a random value between 0 and 255
            new_value = np.random.randint(0, 256)
            # Update the buffer with the new value
            buffer[index] = new_value
            # Increment the buffer index
            index += 1
            # Check if the buffer index has reached the end
            if index == buffer.shape[0]:
                # Shift the buffer back by one element and add the new value at the end
                buffer[:-1] = buffer[1:]
                buffer[-1] = new_value
                # Reset the buffer index
                index = buffer.shape[0] - 1
        # Reshape the buffer into a 150x150 image
        image = Image.fromarray(buffer.reshape((150, 150)), mode="L")
    else:
        # Run tcpdump to capture a packet
        cmd = ['tcpdump', '-i', 'lo', '-x', '-XX', '-l']
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
        # Read the packet bytes from the tcpdump output
        packet_bytes = b''
        for line in iter(proc.stdout.readline, b''):
            line = line.decode().strip()
            if line.startswith('0x'):
                hex_data = extract_packet_data(line)
                packet_bytes += bytes(hex_data)
            if len(packet_bytes) >= 1000:
                break
        # Update the buffer with the new values
        new_values = np.frombuffer(packet_bytes, dtype=np.uint8) + 1
        buffer[index:index+len(new_values)] = new_values
        # Increment the buffer index
        index += len(new_values)
        # Check if the buffer index has reached the end
        if index >= buffer.shape[0]:
            # Shift the buffer back by the length of the new values and add the new values at the end
            buffer[:-len(new_values)] = buffer[len(new_values):]
            buffer[-len(new_values):] = new_values
            # Reset the buffer index
            index = buffer.shape[0] - len(new_values)
        # Reshape the buffer into a 150x150 image
        image = Image.fromarray(buffer.reshape((150, 150)), mode="L")
    return image, buffer, index



def show_Image(Im, key):
    image =Im
    # Resize the image to a larger size
    image = image.resize((600, 600))
    bio = io.BytesIO()
    image.save(bio, format="PNG")
    window[key].update(data=bio.getvalue()) # Updating the GUI window using the key that passed in

# Define the PySimpleGUI layout
layout = [
    [sg.Image(key='-IMAGE-')],
]

# Create the PySimpleGUI window
window = sg.Window('Image Viewer', layout)
buffer_size = 22500
buffer_index = 0
buffer = np.zeros((buffer_size,), dtype=np.uint8)
# Event loop
while True:
    event, values = window.read(timeout=10) # Add timeout to the read function to prevent blocking the loop
    if event == sg.WIN_CLOSED:
        break
    # Call the create_and_update_image() function to get the updated image file name
    # Call the create_and_update_image() function to get the updated image and the new buffer state
    image, buffer, buffer_index = create_and_update_image(buffer, buffer_index)

    # Update the image in the PySimpleGUI window
    show_Image(image, '-IMAGE-')
    window.refresh()
# Close the window
window.close()

