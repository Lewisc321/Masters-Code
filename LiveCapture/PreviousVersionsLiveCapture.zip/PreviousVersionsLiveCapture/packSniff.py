#!/usr/bin/env python3
import struct
import sys,os
import socket
import binascii
import csv

file = open('CSVSnifferTestFile.csv', 'w')
rawSocket=socket.socket(socket.PF_PACKET,socket.SOCK_RAW,socket.htons(0x0800))
i = 0;
topLine = 'Ethernet Destination, Ethernet Source, Ethernet Protocol, Source IP, Destination IP, TCP PORT OUT, TCP PORT IN, TCP FLAG \n'
bigfile = topLine
while(i <1000):
    newline = ''
    #ifconfig eth0 promisc up
    receivedPacket=rawSocket.recv(2048)

    #Ethernet Header...
    ethernetHeader=receivedPacket[0:14]
    ethrheader=struct.unpack("!6s6s2s",ethernetHeader)
    destinationIP= binascii.hexlify(ethrheader[0])
    sourceIP= binascii.hexlify(ethrheader[1])
    protocol= binascii.hexlify(ethrheader[2])

    newline = str(destinationIP) + ','
    newline =newline + str(sourceIP) +','
    newline =newline +str(protocol) +','

    #IP Header... 
    ipHeader=receivedPacket[14:34]
    ipHdr=struct.unpack("!12s4s4s",ipHeader)
    destinationIP=socket.inet_ntoa(ipHdr[2])
    sourceIP=socket.inet_ntoa(ipHdr[1])
    newline =newline +"Source IP: " +str(sourceIP) + ','
    newline =newline + str(destinationIP)+ ','

    tcp_header = receivedPacket[34:54]
    tcp_info = struct.unpack('!HH9ss6s', tcp_header)
    source_port, dest_port, _, flags, _ = tcp_info
    newline =newline + str(source_port) + ','
    newline = newline + str(dest_port)  + ','
    newline = newline + str(binascii.hexlify(flags).decode())
    newline = newline + '\n'
    bigfile = bigfile + newline
    i = i+1
file.write(bigfile)   
file.close() 


