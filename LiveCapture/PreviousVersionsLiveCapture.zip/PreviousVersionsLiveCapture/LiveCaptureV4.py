import numpy as np
from PIL import Image
from scapy.all import sniff
import platform
import PySimpleGUI as sg
import io


def create_and_update_image(buffer, index):
    if platform.system() == 'Windows':
        num_pixels = np.random.randint(50, 151)
        for i in range(num_pixels):
            new_value = np.random.randint(0, 256)
            buffer[index] = new_value
            index += 1
            if index == buffer.shape[0]:
                buffer[:-1] = buffer[1:]
                buffer[-1] = new_value
                index = buffer.shape[0] - 1
    else:
        packets = sniff(count=100, iface="lo")
        new_values = []
        for packet in packets:
            if packet.haslayer('Raw'):
                data = packet.getlayer('Raw').load
                for byte in data:
                    byte = byte + 1
                    if byte > 255: 
                        byte = 255
                    new_values += [byte]
        if not new_values:  # if new_values is empty, return a black image
            return Image.fromarray(np.zeros((150, 150), dtype=np.uint8), mode="L"), buffer, index
        new_values = np.array(new_values, dtype=np.uint8)
        buffer[index:index+len(new_values)] = new_values
        index += len(new_values)
        if index >= buffer.shape[0]:
            buffer[:-len(new_values)] = buffer[len(new_values):]
            buffer[-len(new_values):] = new_values
            index = buffer.shape[0] - len(new_values)
    image = Image.fromarray(buffer.reshape((150, 150)), mode="L")       
    return image, buffer, index


def show_Image(Im, key):
    image =Im
    # Resize the image to a larger size
    image = image.resize((600, 600))
    bio = io.BytesIO()
    image.save(bio, format="PNG")
    window[key].update(data=bio.getvalue()) # Updating the GUI window using the key that passed in

# Define the PySimpleGUI layout
layout = [
    [sg.Image(key='-IMAGE-')],
]

# Create the PySimpleGUI window
window = sg.Window('Image Viewer', layout)
buffer_size = 22500
buffer_index = 0
buffer = np.zeros((buffer_size,), dtype=np.uint8)
# Event loop
while True:
    event, values = window.read(timeout=10) # Add timeout to the read function to prevent blocking the loop
    if event == sg.WIN_CLOSED:
        break
    # Call the create_and_update_image() function to get the updated image and the new buffer state
    image, buffer, buffer_index = create_and_update_image(buffer, buffer_index)

    # Update the image in the PySimpleGUI window
    show_Image(image, '-IMAGE-')
    window.refresh()
# Close the window
window.close()

