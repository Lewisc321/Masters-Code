import numpy as np
from PIL import Image
import PySimpleGUI as sg
import platform
import subprocess
import io
import re

# Initialize the image buffer
image_buffer = np.zeros((150, 150), dtype=np.uint8)
row_idx = 0

# Define the PySimpleGUI layout
layout = [
    [sg.Text('Packet capture:', font='Helvetica 16')],
    [sg.Image(data=Image.fromarray(image_buffer.astype(np.uint8)).tobytes(), key='-IMAGE-')],
    [sg.Button('Start'), sg.Button('Stop'), sg.Button('Exit')]
]

# Create the PySimpleGUI window
window = sg.Window('Packet Capture', layout)

# Start capturing packets
process = None
while True:
    event, values = window.read(timeout=100)
    if event == sg.WINDOW_CLOSED or event == 'Exit':
        break
    elif event == 'Start':
        # Determine the dumpcap command based on the platform
        if platform.system() == 'Windows':
            cmd = ['"C:\\Program Files\\Wireshark\\dumpcap.exe"', '-i', '\\Device\\NPF_Loopback', '-P', '-w', '-']
        else:
            cmd = ['tcpdump', '-i', 'lo', '-x', '-XX', '-l']
        # Start the dumpcap process to capture packets
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, universal_newlines=True)
        # Enable the Stop button and disable the Start button
        window['Start'].update(disabled=True)
        window['Stop'].update(disabled=False)
    elif event == 'Stop':
        # Terminate the dumpcap process
        if process is not None:
            process.terminate()
        # Disable the Stop button and enable the Start button
        window['Start'].update(disabled=False)
        window['Stop'].update(disabled=True)

        # Clear the output buffer
        window['-PACKETS-'].update('')

    # Check if there is any output from the dumpcap process
    if process is not None:
        output = process.stdout.readline()
        if re.match('^[0-9a-fA-F ]+$', output.strip()):
            # Convert the output bytes to a NumPy array
            output_bytes = bytes.fromhex(output.strip().replace(' ', ''))
            output_arr = np.frombuffer(output_bytes, dtype=np.uint8)

            # Add the packet data to the image buffer
            for pixel_idx, pixel_val in enumerate(output_arr):
                image_buffer[row_idx, pixel_idx] = pixel_val + 1  # add 1 to distinguish from filler
            row_idx = (row_idx + 1) % 150  # update row index for next packet data

            # Update the image in the window
            window['-IMAGE-'].update(data=Image.fromarray(image_buffer.astype(np.uint8)).tobytes())

# Close the window
window.close()

