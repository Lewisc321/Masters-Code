import os
import shutil
import random
from tqdm import tqdm


def extract_balanced_datasets(root_folder, num_records, train_ratio, valid_ratio, test_ratio, num_datasets):
    # Find all files in the datapool
    all_files = []
    for root, dirs, files in os.walk(root_folder):
        for file in files:
            all_files.append(os.path.join(root, file))

    # Count the occurrences of each subcategory in the folder paths
    subcategory_counts = {}
    for file in all_files:
        parts = file.split(os.path.sep)
        categories = parts[1:-1]
        for i in range(len(categories)):
            subcategory = os.path.join(*categories[:i+1])
            if subcategory not in subcategory_counts:
                subcategory_counts[subcategory] = 0
            subcategory_counts[subcategory] += 1

    # Calculate the number of records to extract for each subcategory
    total_records = len(all_files)
    subcategory_ratios = {}
    for subcategory, count in subcategory_counts.items():
        ratio = count / total_records
        subcategory_ratios[subcategory] = ratio
    subcategory_records = {subcategory: int(num_records * ratio) for subcategory, ratio in subcategory_ratios.items()}

    # Create the train, valid, and test sets with balanced records across categories and subcategories
    for i in range(num_datasets):
        train_dir = os.path.join('Datasets', 'v3Dataset', f'Dataset{i+1}', 'train')
        valid_dir = os.path.join('Datasets', 'v3Dataset', f'Dataset{i+1}', 'valid')
        test_dir = os.path.join('Datasets', 'v3Dataset', f'Dataset{i+1}', 'test')
        os.makedirs(train_dir, exist_ok=True)
        os.makedirs(valid_dir, exist_ok=True)
        os.makedirs(test_dir, exist_ok=True)
        
        # Initialize train_num, valid_num, and test_num
        train_num = int(num_records * train_ratio)
        valid_num = int(num_records * valid_ratio)
        test_num = int(num_records * test_ratio)

        selected_files = []
        for subcategory, num_subcategory_records in subcategory_records.items():
            subcategory_files = [file for file in all_files if subcategory in file]
            random.shuffle(subcategory_files)
            selected_files.extend(subcategory_files[:min(num_subcategory_records, len(subcategory_files))])

        random.shuffle(selected_files)
        new_dataset_files = selected_files[:num_records]
        

        # First progress bar for all files
        with tqdm(total=len(new_dataset_files), desc=f"Copying files for Dataset {i+1}") as pbar:
            for file in new_dataset_files:
                pbar.update(1)
                if train_num > 0:
                    dest_dir = train_dir
                    train_num -= 1
                elif valid_num > 0:
                    dest_dir = valid_dir
                    valid_num -= 1
                else:
                    dest_dir = test_dir
                filename = os.path.basename(file)
                shutil.copy(file, os.path.join(dest_dir, filename))

        print(f"Dataset {i+1} extraction complete.")
    
extract_balanced_datasets('DataPool', 10000, 0.7, 0.2, 0.1, 15)
